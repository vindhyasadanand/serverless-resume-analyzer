import axios from 'axios'

const API_BASE_URL = import.meta.env.VITE_API_URL || 'https://qhkubp0tt2.execute-api.us-east-1.amazonaws.com/dev'

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
})

export const analyzeResume = async (resumeText, jobDescription) => {
  // If resumeText is a File, send as form-data
  if (resumeText instanceof File) {
    const formData = new FormData();
    formData.append('resume', resumeText);
    formData.append('job_description', jobDescription);
    const response = await api.post('/analyze', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response.data;
  } else {
    // Fallback: send as JSON (for text input)
    const response = await api.post('/analyze', {
      resume: resumeText,
      job_description: jobDescription
    });
    return response.data;
  }
}

export const getHistory = async (limit = 50) => {
  const response = await api.get(`/api/history?limit=${limit}`)
  return response.data
}

export const getAnalysis = async (id) => {
  const response = await api.get(`/api/analysis/${id}`)
  return response.data
}

export const deleteAnalysis = async (id) => {
  const response = await api.delete(`/api/analysis/${id}`)
  return response.data
}

export const getStats = async () => {
  const response = await api.get('/api/stats')
  return response.data
}

export default api






